import streamlit as st
import plotly.express as px
import pandas as pd
st.set_page_config(page_title="Teacher Heart Report", layout="wide")
st.title("Teacher Heart KPR")
st.markdown("<style>div.block-container{padding: 1rem}</style>", unsafe_allow_html=True)
df= pd.DataFrame({"Name":["Minahil", "Other"], "Importance": [1000,200]})
name_value = df.iloc[0, 0]
with open("style.css") as file:
    st.markdown(f"<style>{file.read()}</style>", unsafe_allow_html=True)
selects= st.multiselect("Total Options Teacher Have ", options=df[df["Name"]=="Minahil"])



if not selects :
    col1, col2, col3 = st.columns((3))
    with col1:
        st.metric(label="What Teacher Like the Most", value=name_value)
        st.metric(label="What Teacher Need the Most", value=name_value)
        st.metric(label="What Teacher Remember the Most", value=name_value)
    with col2:
        fig = px.bar(df, x="Name", y="Importance", width=300, height=300, color="Name", title="Teacher Heart Bar")
        fig.update_xaxes(title_text="")
        fig.update_yaxes(title_text="")
        fig.update_yaxes(tickvals=[], ticktext=[])
        st.plotly_chart(fig)
    with col3:
        fig = px.pie(df, values="Importance", labels="Name", color="Name", width=200, height=300,
                     title="Teacher Imporatnce Rate")
        st.plotly_chart(fig, use_container_width=True)
elif selects is not None:
    st.write("""There's a certain magic in your smile, a warmth that brightens my day in a way nothing else can. You're the person I care about most, the one I dream of spending every free moment with. Life throws its curveballs sometimes, and work keeps me busier than I'd like. 
    But know this: even when we're apart, you're always in my thoughts. Here's to hoping the future holds more time for us to create those cherished moments together. Until then, you have my unwavering affection and the promise of brighter days ahead.""")
